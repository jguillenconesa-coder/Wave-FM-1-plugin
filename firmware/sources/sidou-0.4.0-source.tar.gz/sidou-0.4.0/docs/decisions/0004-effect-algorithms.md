<!-- SPDX-FileCopyrightText: 2026 SIDOU contributors -->
<!-- SPDX-License-Identifier: GPL-3.0-or-later -->
# 0004: Effect algorithms for the Distortion, Modulation and FX slots

- **Status:** accepted
- **Date:** 2026-10-15

## Context

M1c Task 5 puts three slots after each chip: Distortion → Modulation → FX,
with stereo from Modulation on. Each slot runs one algorithm at a time. The
constraints:
- pi32v2 at 240 MHz (budgeted) or 360 MHz (measured by Melodee), with a
  single-precision FPU, no libm and about 512 KB of SRAM shared with
  everything (`docs/hardware.md` on `m1a-device`);
- `POOL` is 360 KiB, and the M1a firmware uses 19.1 KiB of it
  (`_pool_end`);
- the hardware float-biquad EQ isn't in fm1-emu, so the gate can't count it.

Measured on pi32v2 (fm1-emu, `build/fm1/*_budget_*.json`):
- the SID core costs 366 instructions per sample per chip on the M0 workload
  (budget 900, worst case about 600);
- the Task 1 chain (crush, tape, wow, CRT, noise) costs 455 at worst.

We don't have per-block costs. Shared by op count, the 455 splits roughly
into about 60 of frame overhead (int16 conversions, smoothing), crush ~30,
tape ~110 (residual ADAA, branchy), wow ~120 (Hermite read, two LFOs,
drift), CRT ~80 and noise ~30. Below, "≈" marks an estimate calibrated
against these figures. Unit costs: a linear delay read ~14, a Hermite read
~30, an int16 store with rounding ~12, and `sid_fx_sin` ~10. The emulator
gate in Task 5 replaces every estimate with a measurement.

## Sources reviewed

- J. Dattorro, "Effect Design":
  - [Part 1: Reverberator and Other Filters](https://ccrma.stanford.edu/~dattorro/EffectDesignPart1.pdf),
    JAES 45(9), 1997;
  - [Part 2: Delay-Line Modulation and Chorus](https://ccrma.stanford.edu/~dattorro/EffectDesignPart2.pdf);
  - [Part 3: Oscillators: Sinusoidal and Pseudonoise](https://ccrma.stanford.edu/~dattorro/EffectDesignPart3.pdf).
- J. O. Smith, [*Physical Audio Signal Processing*](https://ccrma.stanford.edu/~jos/pasp/)
  (CCRMA online), including the
  [Freeverb analysis](https://ccrma.stanford.edu/~jos/pasp/Freeverb.html).
- U. Zölzer (ed.), [*DAFX: Digital Audio Effects*, 2nd ed.](https://www.wiley.com/en-us/DAFX%3A+Digital+Audio+Effects%2C+2nd+Edition-p-9780470665992),
  Wiley 2011.
- W. Pirkle, [*Designing Audio Effect Plugins in C++*, 2nd ed.](https://www.routledge.com/Designing-Audio-Effect-Plugins-in-C-For-AAX-AU-and-VST3-with-DSP-Theory/Pirkle/p/book/9781138591936),
  Routledge 2019.
- V. Zavalishin, *The Art of VA Filter Design*, rev. 2.1.0
  ([NI-hosted PDF](https://www.native-instruments.com/fileadmin/ni_media/downloads/pdf/VAFilterDesign_2.1.0.pdf)).
  Web search lists this link, but it returned 404 to a direct fetch on
  2026-10-15.
- Valhalla DSP, "Getting Started With Reverb Design", parts 1–4 (2021;
  [part 1](https://valhalladsp.com/2021/09/20/getting-started-with-reverb-design-part-1-dev-environments/embed)).
  The site refuses scripted fetches, so this is confirmed by search only.
- Signalsmith Audio, ["Let's Write a Reverb"](https://signalsmith-audio.co.uk/writing/2021/lets-write-a-reverb/).
- ADAA:
  - Parker, Zavalishin and Le Bivic, ["Reducing the Aliasing of Nonlinear Waveshaping Using Continuous-Time Convolution"](https://www.dafx.de/paper-archive/2016/dafxpapers/20-DAFx-16_paper_41-PN.pdf),
    DAFx-16;
  - Bilbao, Esqueda, Parker and Välimäki, ["Antiderivative Antialiasing for Memoryless Nonlinearities"](https://ieeexplore.ieee.org/document/7865908),
    IEEE SPL 24(7), 2017;
  - J. Chowdhury, [ADAA notebook](https://ccrma.stanford.edu/~jatin/Notebooks/adaa.html).
- J. Chowdhury:
  - ["Real-Time Physical Modelling for Analog Tape Machines"](https://dafx.de/paper-archive/details/Z5Ow_E5YHVxvndTAyeEuzA),
    DAFx 2019;
  - ["chowdsp_wdf: An Advanced C++ Library for Wave Digital Circuit Modelling"](https://arxiv.org/abs/2210.12554),
    2022.

## Open code and licences

All checked on 2026-10-15 against the files linked.

| Project | Licence (SPDX) | GPL-3.0 compatible | Notes | Use |
|---|---|---|---|---|
| Mutable Instruments eurorack: Clouds, Rings, Elements, Plaits, Beads `dsp/fx/*` | MIT ([README](https://github.com/pichenettes/eurorack/blob/master/README.md): STM32 projects MIT, AVR projects GPL-3.0; per-file headers, e.g. [rings/dsp/fx/reverb.h](https://github.com/pichenettes/eurorack/blob/master/rings/dsp/fx/reverb.h)) | yes ([FSF: Expat](https://www.gnu.org/licenses/license-list.html#Expat)) | "Mutable Instruments" is a registered trademark; the README asks derivatives not to use the name | **port** the reverb topology and constants; follow the ensemble topology |
| [stmlib](https://github.com/pichenettes/stmlib/blob/master/LICENSE) | MIT | yes | | reference only |
| [DaisySP](https://github.com/electro-smith/DaisySP/blob/master/LICENSE) | MIT | yes | chorus, flanger, phaser, overdrive and tremolo are in this repo | reference only |
| [DaisySP-LGPL](https://github.com/electro-smith/DaisySP-LGPL/blob/main/LICENSE) | LGPL-2.1 | yes ([FSF](https://www.gnu.org/licenses/license-list.html#LGPLv2.1)) | `reverbsc`, `bitcrush` and `fold` live here; ReverbSc reserves `float aux_[98936]` (387 KiB) | **not used**: too large, and we avoid the relink obligation |
| [Airwindows](https://github.com/airwindows/airwindows/blob/master/LICENSE) | MIT | yes | double-precision plugin code | listening reference only |
| Freeverb (Jezar) | public domain ([readme mirror](https://github.com/sinshu/freeverb/blob/master/readme.txt); [PASP](https://ccrma.stanford.edu/~jos/pasp/Freeverb.html)) | yes ([FSF](https://www.gnu.org/licenses/license-list.html#PublicDomain)) | 16 combs and 8 allpasses for stereo; metallic on bright tones | rejected |
| CloudSeed ([original](https://github.com/ValdemarOrn/CloudSeed/blob/master/license.txt), [CloudSeedCore](https://github.com/GhostNoteAudio/CloudSeedCore/blob/master/LICENSE)) | MIT | yes | many diffuser stages and multitap lines: far over budget | rejected |
| [chowdsp_utils](https://github.com/Chowdhury-DSP/chowdsp_utils/blob/master/LICENSE.md) | per module: `chowdsp_math`, `_buffers` and `_simd` are BSD-3-Clause; `chowdsp_waveshapers`, `_reverb`, `_filters` and `_dsp_utils` say "GPLv3" (-only or -or-later is not stated) | yes; GPL-3.0-only would make a ported file GPL-3.0-only (allowed by LICENSING.md, but avoided) | | reference only |
| [chowdsp_wdf](https://github.com/Chowdhury-DSP/chowdsp_wdf/blob/main/LICENSE) | BSD-3-Clause | yes ([FSF](https://www.gnu.org/licenses/license-list.html#ModifiedBSD)) | C++14 templates | reference only |
| [ChowTape / AnalogTapeModel](https://github.com/jatinchowdhury18/AnalogTapeModel/blob/master/LICENSE) | GPL-3.0 (version suffix not stated; the iOS build is also MPL-2.0) | yes | a hysteresis solver with oversampling, many times our budget | rejected; the existing tape stays |

**No incompatible licence was found.** The only non-permissive parts are:
- DaisySP-LGPL (LGPL-2.1);
- ChowTape and the GPL modules of chowdsp_utils (GPL-3.0).

We take code from neither.

## Decision

Each choice below lists:
- the algorithm and its source;
- **P** (port: code translated to our C) or **R** (reimplemented from the
  published description);
- the cost in pi32v2 instructions per sample (≈ estimated);
- the memory it needs.

### Distortion (mono)

| Entry | Algorithm, source | | Cost | Memory |
|---|---|---|---|---|
| Tape | existing `fx_tape.h`: emphasis, biased cubic clip, residual ADAA1 | — | ≈110 | 48 B |
| Overdrive | Mid-hump pre-filter (x + k·one-pole HP at ~700 Hz), the tape's cubic clip with **residual ADAA1** (shared, not copied), Amount → gain law after Plaits `Overdrive`, Param A = post tone (one-pole LP), Param B = bias | R; gain law follows Plaits (MIT) | ≈100 | 40 B |
| Fuzz | Pre low-pass (~7 kHz, one-pole) → hard clip u ↦ clamp(u, ±1) with closed-form ADAA1 of the residual (piecewise linear means, no division off the knee), Param B = bias (gated "starved" asymmetry), Param A = blend with full-wave rectified \|x\| (octave-up, also ADAA1) | R from Parker 2016 / Bilbao 2017, Zölzer (nonlinear processing chapter) | ≈120 | 40 B |
| Crush | existing `fx_crush.h` | — | ≈30 | 12 B |
| Lo-fi | existing `fx_crt.h` + `fx_noise.h` | — | ≈110 | ~1 KB tables |

**Anti-aliasing: first-order ADAA, no oversampling.**
- **Why not oversampling:** 2× oversampling needs a halfband up and down
  (~2 × 10 MACs) plus a second nonlinearity evaluation, about 60–80 extra.
  The hardware EQ could filter, but it is block-based and not emulated.
- **What ADAA keeps:** the residual form keeps small signals flat to
  Nyquist and costs only a branchy mean.
- **Fuzz:** the pre-filter also tames the SID's saw and pulse highs, the
  main source of aliasing.
- **When to revisit:** if the alias test (a 5 kHz saw at full drive, with
  aliases at −60 dB against the reference) fails, Fuzz gets 2×
  oversampling within its 150 budget.

**Why these suit a SID:**
- The SID's pulse is already square, so clipping it adds little. The drives
  act mainly on resonant filter sweeps, triangle and mixes.
- The mid-hump and the bias give overdrive and fuzz audibly different
  odd/even balances.

### Modulation (mono in, stereo out)

| Entry | Algorithm, source | | Cost | Memory |
|---|---|---|---|---|
| Chorus/ensemble | One float line, 3 taps per side at 120° phases, slow (~0.6 Hz) + fast (~6 Hz) LFO sum (Solina-style); linear reads (`fx_delay.h`). Dattorro Part 2; topology as Plaits `ensemble.h` | R (Plaits MIT as reference) | ≈130 | 1,024 float = 4 KiB |
| Flanger | Hermite read, 0.1–10 ms sweep, feedback ±0.9 through a soft clip; R tap at 90° LFO offset | R from Dattorro Part 2 | ≈100 | 512 float = 2 KiB |
| Phaser | 6 first-order allpasses with a shared coefficient per side, coefficient from an LFO over a log-frequency table (CRT-style interpolation), feedback; L/R LFOs in quadrature | R from Zölzer (first-order allpass in transposed direct form II; Zavalishin as background) | ≈110 | 64 B |
| Tremolo/auto-pan | `sid_fx_sin` LFO, shape (sine→square by soft clip), gain or equal-power pan via sin/cos approximations | R | ≈40 | 16 B |
| Wow & flutter | existing `fx_wow.h`, mono to both sides | — | ≈120 | 4 KiB |

**Why these suit a SID:**
- The SID is mono and bone dry. An ensemble widens it the way 80s string
  machines widened their dividers.
- The flanger and phaser emphasise its sweeping pulse width.

### FX (stereo in; the wet path takes (L+R)/2, the dry path stays stereo)

| Entry | Algorithm, source | | Cost | Memory |
|---|---|---|---|---|
| Delay | One int16 line; mono = tap at T; ping-pong = taps at T (L) and 2T (R), feedback from 2T (equal-time ping-pong needs only one line); one-pole damping and a soft clip in the feedback; linear read (Hermite only while T glides) | R | ≈90 | 65,536 int16 = **128 KiB** (1.49 s mono, 0.74 s per side ping-pong) |
| Reverb light | MI Rings/Clouds reverb: 4 input allpasses, then a two-branch loop (2 allpasses + delay each) with a one-pole damping per branch, 2 slow LFO-modulated reads, all lines in one ring with one write pointer (FxEngine style); delays scaled 48→44.1 kHz | **P** (MIT) | ≈260 | ~19.9k samples in a 32,768 int16 ring = 64 KiB |
| Reverb lush | Dattorro plate (Part 1, fig. 1): pre-delay, 4 input diffusers, a figure-8 tank with 2 modulated allpasses, 2 fixed allpasses, 4 delays, bandwidth and damping one-poles, 7 output taps per side; delays scaled ×1.48 to 44.1 kHz, then ×0.98 to fit the same 32,768 ring | R from the paper | ≈380 | 64 KiB (shared) |

- **Why these suit a SID:**
  - Short, bright envelopes need a dense, smooth tail without a metallic
    ring, which rules out Freeverb.
  - The modulated tank (MI and Dattorro both have one) smears the SID's
    perfectly stable pitch.
  - Rhythmic ping-pong is the classic chiptune echo.
- **Light and lush:** light is a proven embedded design (Clouds and Rings
  run it on STM32F4 modules, at 32 kHz and 48 kHz by their LFO settings).
  Lush ships only if the gate measures it within the FX budget with two
  chips.
- **Switching inside the FX slot:**
  - Delay and reverb share one 128 KiB pool, because only one runs at a
    time.
  - A switch fades the old wet path out over 20 ms, clearing the ring
    incrementally (~40 extra instructions per sample during the fade), then
    fades the new one in.
  - The dry path is continuous, so there is no click; the old tail is cut.
  - Running both at once would double the slot's cost.

## Slot budgets

At 240 MHz and 44.1 kHz: 240e6 / 44,100 ≈ **5,442 instructions per sample**
per core, at 1 IPC. The design doc reserves ≤ 2,700 (50 %) for audio, and
the rest goes to UI, MIDI and the sequencer.

| Block | Budget | Heaviest entry (≈) |
|---|---|---|
| Distortion | 150 | Fuzz 120 |
| Modulation | 200 | Chorus 130 |
| FX | 450 | Lush 380 |
| Slot frame: int16↔float, 4 smoothed parameters × 3 slots, mix, crossfade, stereo out | 100 | — |
| **Slots total** | **900** | ≈730 |

**Worst cases:**

| Case | SID | Slots | 6502 (future) | ISR overhead (estimate) | Total | Share of one core |
|---|---|---|---|---|---|---|
| Measured SID (worst ~600 × 2) | 1,200 | 900 | 400 | 100 | **2,600** | 48 % |
| SID at its budget (900 × 2) | 1,800 | 900 | 400 | 100 | 3,200 | 59 % |

- The measured case fits the 2,700 audio target with 100 to spare. Without
  the future 6502, SID plus effects is 2,100, inside Task 1's 2,300 cap.
- The budget case is over the target and invokes the design doc's cut
  order (chip B oversampling first).
- 360 MHz (8,163 per sample) would hold even the budget case at 39 %, but
  we spend that only after cycles are measured on a unit.
- The gate asserts each slot budget separately and the 2,300 total for two
  chips (since M1b with the SID's worst block, not ~600 per chip: see
  "Worst blocks").

## SRAM budget

| Buffer | Size |
|---|---|
| FX pool (delay, or either reverb) | 128 KiB |
| Modulation lines (chorus 4 KiB, flanger 2 KiB; wow's 4 KiB is already in `sid_fx`) | 6 KiB new |
| **Effects total** | **≈ 138 KiB of POOL's 360 KiB** |

- After the M1a firmware (19.1 KiB) and a future 64 KiB C64 RAM image,
  about 139 KiB of POOL remains.
- Effect buffers are int16 wherever they're long. Float is used only where
  a short line is read many times (modulation).

## Attribution

- **CREDITS.md**, under "Signal processing":
  - Emilie Gillet / Mutable Instruments: the reverb ported from
    Rings/Clouds, and the ensemble topology from Plaits;
  - Jon Dattorro: the plate reverb, and the chorus and flanger designs;
  - Julian Parker, Vadim Zavalishin, Efflam Le Bivic, Stefan Bilbao, Fabián
    Esqueda and Vesa Välimäki: ADAA;
  - Jatin Chowdhury: tape-modelling background.
- **LICENSING.md**, third-party table: one row for the ported reverb, with
  origin `pichenettes/eurorack` at a pinned commit, licence MIT, use
  "compiled into the firmware". That ported file:
  - keeps Emilie Gillet's copyright line and the MIT notice in its header,
    as dual `SPDX-FileCopyrightText` lines;
<!-- REUSE-IgnoreStart -->
  - carries `SPDX-License-Identifier: MIT`;
<!-- REUSE-IgnoreEnd -->
  - adds the MIT text to `LICENSES/MIT.txt` (REUSE).
- **Not under the MI name:** the reverb is never called by the MI module's
  name in the UI (the README asks this).
- **Reimplementations from papers** carry only our header and a comment
  citing the paper. "Follows" (as for the Plaits gain law) needs no licence
  row, just the credit.

## Consequences

- Task 5 builds:
  - Overdrive, Fuzz, Chorus, Flanger, Phaser, Tremolo/auto-pan, Delay and
    the two reverbs;
  - a shared residual-ADAA helper taken out of `fx_tape.h`.
- The emulator gate measures every algorithm and replaces each "≈" here.
  An entry that is over its slot budget gets cheaper (fewer taps or stages)
  before the budget moves.
- Not verified:
  - the Zavalishin and Valhalla links (they refuse scripted fetches; found
    by search);
  - whether chowdsp's and ChowTape's "GPLv3" is -only or -or-later. This
    doesn't matter, because we take no code from them.

## Measured (Task 5)

The emulator gate (`slots_budget.rs`, pi32v2 in fm1-emu, every control
moving all the time) replaces the estimates above. Instructions per sample:

| Entry | Slot | Measured | Estimate | Budget |
|---|---|---|---|---|
| Tape | Distortion | 116 | ≈110 | 150 |
| Overdrive | Distortion | 144 | ≈100 | 150 |
| Fuzz | Distortion | 107 | ≈120 | 150 |
| Crush | Distortion | 52 | ≈30 | 150 |
| Lo-fi | Distortion | 115 | ≈110 | 150 |
| Chorus/ensemble | Modulation | 183 | ≈130 | 200 |
| Flanger | Modulation | 158 | ≈100 | 200 |
| Phaser | Modulation | 154 | ≈110 | 200 |
| Tremolo | Modulation | 101 | ≈40 | 200 |
| Auto-pan | Modulation | 155 | ≈40 | 200 |
| Wow & flutter | Modulation | 143 | ≈120 | 200 |
| Delay | FX | 157 | ≈90 | 450 |
| Ping-pong | FX | 174 | ≈90 | 450 |
| Reverb light | FX | 373 | ≈260 | 450 |
| Reverb lush | FX | 421 | ≈380 | 450 |
| Slot frame | — | 91 | — | 100 |
| Heaviest of each together (overdrive, chorus, lush) | — | 839 | ≈730 | 900 |

- One chip plus the slots: 1,201 (22 % of a 240 MHz core).
- Two chips plus the slots: 1,576 (29 %), within Task 1's 2,300.
- RAM: 136,328 bytes. That is the 128 KiB pool plus 5,256 bytes of slot
  state (the Modulation union is the largest part, at 4.1 KiB).

How the frame and the modulations got within budget (the first build
measured a 256 frame, chorus 289 and lush 829):
- the frame runs in 16-sample chunks on its own clock, controls following
  their one-pole as straight lines between chunk starts;
- each algorithm has its own loop in the steady state;
- the modulations evaluate their LFOs every 16 samples and interpolate.

(The delays' cost includes the eased time glide, added after review.)

### Switching: a bounded transient allowance

A preset change can switch every slot. While a slot switches, its old algorithm still
runs (fading out) through the per-sample switching path, and then the new one starts
up. The gate's switch scenario (`workload_slots.h`) measures this per 32-sample block,
going from every slot's heaviest (overdrive, chorus, lush) to fuzz, flanger and light,
and back. Per sample:

- **Before review: 1,026.** All three slots switched at once, each through the
  per-sample path, for the whole 20 ms fade-out.
- **Tried: one dispatch per run of samples** instead of per sample, with gain arrays.
  It brought nothing (about 1,010, since the old algorithms still run), and it slowed
  the steady state (frame 99). Dropped.
- **Chosen: slots take turns.** A slot starts a switch only while no other slot is
  switching, decided per 16-sample chunk on the slots' clock (in slot order, so block
  sizes never change the result). A preset change then costs at most one switching
  slot's overhead at a time, and takes up to three switch times (about 150 ms) instead
  of one.
- **Slots coming back from rest also take turns.** In the gate's second preset change,
  the Modulation slot (at Mix 0, so at rest) wakes while FX switches into lush. Waking
  out of turn put the chorus's start-up on top of lush's fade-in: 1,066 per sample at
  worst. In turn, the waking slot passes the dry signal until the FX switch is done.
- **Measured: worst block 963, 45 blocks above 900** (about 33 ms in all, over two
  preset changes, one with the wake).
  - Most of those blocks are lush fading in (about 908) or the chorus starting after it
    (about 915).
  - The single worst is the one-off setup when the chorus starts (clearing its line).
  - For scale, the steady state after the switches measures about 840 per 32-sample
    block, against 835 per sample at 128. (The higher figures early in the scenario are
    the distortion fading out, not the steady state.)

**Decision:** an explicit transient allowance, asserted by the gate:
- a switching block may cost up to 1,000 per sample;
- at most 80 of the scenario's 32-sample blocks may be above the 900 budget.

With two chips at the SID's measured worst (2 × 600), the future 6502 (400) and ISR
overhead (100), the worst switching block makes 1,700 + 963 = 2,663, within the 2,700
audio target. The gate asserted that sum too, until M1b replaced it (see "Worst blocks"
below). The steady budget stays 900.

### Worst blocks (M1b, 2026-10-15)

The audio ISR has a hard deadline per 128-sample block (2.9 ms), so the honest pairing
for the gates is the SID's most expensive *block*, not its most expensive scenario on
average (530 per chip at M1b, 557 since M1b Task 6). The SID gate now measures both
and holds the worst block to `SID_WORST_BLOCK_ONE_CHIP` (718) and
`SID_WORST_BLOCK_TWO_CHIPS` (1,440) in `tests/common/mod.rs`; the effect gates take the
latter, with the LIVE view's tap (`TAP_PER_SAMPLE`, 4.5).

**Where the worst block comes from.** Always the first block of a scenario with noise
combined with another waveform, from power-on: the register starts full, the output
writes back into it every cycle, and it runs through about 25 shifts (16 cycles apart
at 0xffff, 256 at 0x0800) before it locks up at 0. Those cycles run in short bulk
windows between single cycles. The worst is `noise_tri_ring_0800` on the 8580: 690.85
per sample for one chip, 1,409.24 for two (M1b merged with M1d, after "perf(sid): cheaper combined-noise
lock-up transient" took them from 752 and 1,492). Its block 0, one chip, 88.4k
instructions (`SIDOU_GATE_PROFILE=1`):

| Part | Instructions in block 0 |
|---|---|
| `sid_osc_run_combined` (window search, commits) | 24,690 |
| `sid_osc_advance_slow` (mostly the quiet-stretch step, ~60 per call) | 10,114 |
| `sid_osc_cycle` (single cycles) | 5,004 |
| `sid_noise_clock` | 777 |
| Envelope attack from 0xaa (`sid_env_advance_slow`, `sid_env_run`) | 8,052 |
| Baseline (`clock_voices` 23,326, `sid_render` 16,405) | 39,731 |

From block 2 on the same scenario costs about 345 per sample. `noise_tri_ffff` (6581,
688) and `noise_tri_0800` (8580, 652; its block 1 still 476 from quiet-stretch calls)
come close.

**Decision.** The 2,700 target stays. The gates pair what exists today, with the LIVE
view's tap (on at power-on, 4.5; below):
- the worst switching block + two chips at the SID's worst block + the tap + ISR
  overhead (100) ≤ 2,700: 964.28 + 1,440 + 4.5 + 100 = 2,508.78;
- two chips at the SID's worst block + the tap + every slot's heaviest ≤ 2,300:
  1,440 + 4.5 + 838.97 = 2,283.47 (and + the post-chip effects, 1,444.5 + 455.20).

The former 400 for the 6502 is no longer in the sum: it does not exist yet (M3). The
gate prints what is left of 2,700 instead, the 6502's headroom: **191** per sample
(227 before M1b Task 6, below, without the tap). docs/TODO.md tracks what to do if the 6502 needs more.

**M1b Task 6 (2026-10-15): the 6581's non-linear filter.** The 6581's filter now moves
its cutoff with the signal and with the DC load of the voices routed into it, mixes its
outputs as reSIDfp's does, and has an output low-pass (`sid_filter.h`, `sid_nl_tick`).
That costs the 6581 about 45 instructions per sample per chip (the triad 362.46 ->
408.05), so the worst blocks are now the 6581's: `noise_tri_ffff`, 725.05 for one chip,
and `noise_tri_ring_0800`, 1,454.80 for two (the 8580's went down, to 687.95 and
1,403.43: its render lost the old 6581 clip's test and runs in its own function). The
constants were raised to those (726, 1,455; `SID_WORST_PER_CHIP` 530 -> 564), the two
sums above still held, and the 6502's headroom fell from 227 to 181.

After review, merged with M1e's LIVE view: LIVE is the view at power-on, and its tap
rendered a block as eight `sid_render` calls, each paying the 6581 render's setup (its
state in locals), 9.09 instructions a sample. `sid_render_tap` now renders a block in
one call and calls the tap every 16 samples; the tap adds 4.44, and the gates count it
(`TAP_PER_SAMPLE`, 4.5). The 6581's tick computes what is fixed between register writes
once a render (`sid_nl_coefs`; the same model up to rounding), about 6.8 instructions a
sample per chip less: the worst blocks are 717.49 and 1,439.67 (constants 718, 1,440;
`SID_WORST_PER_CHIP` 557), and the 8580's 691.16 and 1,409.87. With the tap, the 2,300
sum has 16.53 left; another 6581 instruction per sample per chip in the worst block
takes 2 of it. The 6502's headroom is 191.

**M2b Task 3 (2026-10-16): the device's own two-chip block.** Until M2b the gates added the
second chip from the bench; the firmware now renders chip B beside chip A while it is in
use and mixes them before the slots (`chip_mix`, app/chip_mix.h: `sat16(a + b)`, a linear
fade over the block it goes in or out of use). emu-gate's `chip_b.rs` drives both chips on
the device with noise and ring modulation at 0x0800 on every voice, every slot's heaviest at
full: the worst block 2,388.4 instructions a sample, within 2,700 (not at the gates' sum:
the device cannot replay the bench's power-on transient, the SID's worst block). The mix
itself costs 8.06 a sample in use, so the 6502's headroom is about 197 of the gates' 205.5.
Out of use chip B is not rendered: a held chord costs 398.06 a sample against M1's 397.87.
Headroom at the mix: one chip's loudest steady sample on the bench scenarios is 20,274
(`gate_every_frame`, 6581), so two that loud and in phase clip, by up to 3.3 dB; a gain on
the mix would move chip A's level each time B goes in or out of use, so it is not applied.

(Since M1c Task 2 the algorithms' expensive inits run in `sid_slots_init` as templates
that a switch copies, to fit the device's SRAM code region: the figures above are with
that change.)

### Moved out of Task 5

The device parts of Task 5 move to M1c Task 2 and Task 4, after M1a merges:
- the K1–K4 mapping (Amount, A, B, Mix) and the slot/algorithm button;
- MIDI CC/NRPN;
- storing slot states in presets and songs;
- true L/R output from the audio ISR.

Task 5 delivers the engine (`core/fx/fx_slots.h`) and its tests and gate.

Deviations from the decision above:
- **Overdrive and fuzz use ADAA of the whole clip, not of its residual.**
  - The residual form adds u back undelayed. Far past the knee, u and the
    residual's half-sample lag no longer cancel, and the output approaches
    1 + (u - p) / 2: at 25-100x gain, garbage.
  - The tape keeps the residual form (its drive is 3x at most), so small
    signals stay flat.
- **The alias target of -60 dB is not reachable at full drive.**
  - Measured with an 8 kHz sine and a 5 kHz band-limited saw at half scale:
    overdrive's worst alias below 15 kHz is -28.9 / -27.7 dBc, fuzz's
    -28.5 / -31.0 dBc.
  - An f64 model of the hard clip at these gains gives -14 to -22 dBc
    without ADAA, and -36 to -54 dBc with 2x oversampling (63-tap
    half-bands) on top, well over Fuzz's budget.
  - The tests pin -25 dBc.
- **Lush stores floats.**
  - Its lines are float in the 128 KiB pool (32,768 samples), scaled
    x1.48 then x0.98 as planned.
  - int16 conversions and clamps made it 829. Float costs 421.
  - There is no room for a pre-delay, so B is the input bandwidth.
- **Both reverbs are capped at an RT60 of about 8 s.**
  - Clouds' time goes to 0.98 (tails of minutes); light is capped at 0.82.
  - Dattorro's decay is capped at 0.85.
- **The delay reads linearly.** Its time glides at most 0.5 samples per
  sample (half that in ping-pong), so no Hermite read is needed.
- **The light reverb's LFOs** are this project's phase-accumulator cosine,
  stepped every 32 samples like the original, instead of stmlib's
  oscillator.

## The output's soft limiter (2026-10-23)

Several settings clipped the output: on two loud chips in phase (29,990 out of the mix, two
saws), the flanger, phaser and auto-pan at full feedback or width, ping-pong and both reverbs at
full feedback put 25 to 10,275 samples a 3 s run on a rail (`slots.rs`
`full_feedback_never_reaches_a_rail`; the mono delay peaked at 32,260), and chip B's mix clipped
two chips at their loudest steady level (20,274 each) by 3.3 dB.

- **What:** `core/fx/fx_limit.h`. Up to the knee, K = 24,576 (-2.5 dBFS), a level passes
  unchanged; past it, m = |x| becomes C - H^2 / (m - K + H), H = C - K, C = 32,766: slope 1 at the
  knee, so no corner, and rising ever slower towards C, one inside the rails, which it never
  reaches (Mini-Tone's idea, the curve the thump stage already fits its excess with).
- **Where: once, where the slots convert their output to int16.** A soft knee is not
  idempotent, so the signal must meet it once: chip B's mix keeps the two chips' sum whole
  (`chip_mix`: in a block where some sum is past int16, saturated into the mono block and the
  excess beside it) and the slots take both (`sid_slots_process_wide`); their output conversion
  (`sid_fx_to_i16_limited`) limits, and with every slot out of the path the two chips' whole sum
  goes through the same limiter, so a slot coming into the path at Mix 0 changes nothing. MASTER
  only lowers the level and the thump fits itself under the same ceiling, so after the slots
  nothing reaches a rail: the limiter sits where the excess is, before MASTER, not after it (the
  int16 path after the slots has clamped already, so a limiter after MASTER would see only flat
  tops), and the level it acts on does not move with the MASTER pot. Chip A alone out of the
  slots' path passes as it is: one chip never reaches the knee (its loudest steady sample is
  20,274, its DC blocker's power-on settling 23,834).
- **Transparent below the knee:** a signal that never passes it is the same bit for bit.
- **Cost:** the two compares the clamp cost below the knee; past it a call and a divide, out
  of line (one copy in SRAM, `sid_fx_limit_round`); the excess only in a block that has one.
  Measured: chip B's mix 8.11 a sample (8.08 before), a held chord on one chip 397.29 (397.19),
  every slot's heaviest on one chip 1,194 worst block (1,195), two chips at their worst with every
  slot's heaviest 2,388.8 (2,389.5). RAMTEXT +416 bytes, RAM +256 (a block of no excess).

## The output stage: CHIP SPREAD (2026-10-23)

SETTINGS' SPREAD (`app/chip_spread.h`) pans chip A left and chip B right, 0 (mono) to 100 %,
equal power: the mid (A + B, the slots' input as ever) takes cos phi and the side (A - B)
sin phi, phi = SPREAD x pi / 400, so L = mid cos + side sin, R = mid cos - side sin.

- **After the slots, not before them.** Before them every slot would need a stereo input:
  Distortion and Modulation run once on the mono mix today, and a second channel costs their
  algorithm again, about 144 (overdrive) plus 150 (chorus, less its frame) a sample at their
  heaviest: the heaviest of each together would go from 839 to about 1,130, over the slots'
  900, and the 6502's ISR share would go. After them, every slot's wet path takes the mid (the
  FX slot's wet path always took (L + R) / 2) and the side takes the slots' dry paths only: their
  gain is the product of 1 - Mix x the switch gain over the slots in the path
  (`sid_slots_dry`), taken at each block's end and ramped linearly over the block. Exact for
  the dry paths; a wet path hears the chips as one, so a reverb or a delay adds its own stereo
  tail around the spread pair, and a fully wet distortion is mono.
- **One conversion.** The stage takes the slots' output before its int16 conversion
  (`sid_slots_process_float`) and converts it once through the soft limiter, as the slots
  convert: at SPREAD 0 nothing runs (mono, bit for bit), and at a gain of 1 the stage gives what
  the slots alone give, so it starts and ends without a step. The gains ramp over the block a
  change lands in. The thump stays in the centre (it is added after, as before).
- **The side:** chip A's own output while chip B is out of use, else
  (A - B x chip_mix's fade weight) / 2, its gain doubled; the tail gate mutes it with the mix.
- **Channel separation, not a pan (amended 2026-10-23, the v0.3.0 device session).** At first a
  song alone on chip A went to the left at SPREAD 100; the user: "SPREAD should naturally do
  channel separation". Now the separation acts only while both chips sound: the gains are the
  mono pair's moved towards SPREAD's by a glide g, 0 to 1 over 32 blocks (93 ms), mid
  1 + g (cos phi - 1) and side g sin phi, each block's ramping from the last's (linear in g, so
  within 0.7 dB of equal power half way and exact at either end). Both sound while the quieter
  chip's envelope counters' OR is at 16 (-24 dB) or more; once held, they stay sounding until it
  has been under 4 (-36 dB) for 16 blocks (46 ms): hysteresis in level and in time, so the gaps
  of a phrase do not flutter the image (`chip_spread_glide_step`, once a block in the
  interrupt: the counters, not the output, so it costs nothing a sample). At g = 0 the stage
  does not run, so a chip alone is mono bit for bit at any SPREAD. Measured (`chip_b.rs`): a saw
  alone on A or on B at SPREAD 100 gives L = R at mono's level; both sounding, each chip's
  fundamental is 49 and 68 dB under on the other side; the glide's largest step on a full-scale
  side is 6 LSB (`chip_spread.rs`). The stage's own cost with the glide is 50.26 a sample (bound
  51); RAMTEXT +144 bytes (the glide 58, `audio_fill` 84).
- **Cost** (`chip_b.rs`, two chips at their worst, every slot's heaviest at full, SPREAD
  100): the stage's own instructions 50.56 a sample (bound 51), of which the slots' own
  conversion, about 17, no longer runs: the interrupt's mean rises by about 35. The worst block
  from the notes' start is 2,418.1 (2,387.8 at SPREAD 0; 2,389.5 before the output stage),
  within 2,700. At SPREAD 0 a held chord on one chip costs 397.56 a sample (397.19 before; M1's
  bound 398.87), every slot's heaviest on one chip 1,193 worst block (1,195 before). The
  interrupt's frame holds the slots' float block (1 KiB) and the side (256 bytes): the system
  stack's deepest use is 3,416 bytes (2,096 before), within half of its 7,936. RAMTEXT +752
  bytes (48,704 of 49,152 with the limiter's 416: 448 free; M3 asks for 2,048 free at its
  start, 1,616 before this, so the RAMTEXT win-back M3's plan lists now has 1,600 to find).
