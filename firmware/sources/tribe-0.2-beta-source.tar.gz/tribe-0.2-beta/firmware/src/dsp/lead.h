/* SPDX-License-Identifier: GPL-3.0-only */
/* LEAD: a monophonic lead for long, gliding, legato notes (the thick, screaming leads of tekno and hardtek):
 * up to three detuned oscillators (unison), a sub oscillator, a resonant 4-pole ladder filter that an ADSR
 * opens, and a Drive and distortion stage, plus a ring modulator. Always legato: a note that arrives while
 * the last one still sounds glides to the new pitch and does not start the envelope again. The FX stage is
 * ACID's (acid.c). Vibrato is the LFO's job (the LFO page of the clip).
 *
 *  Cutoff   40 Hz .. 12 kHz, exponential (100 semitones)        Reso    the ladder, up to self-oscillation
 *  Color    saw -> square (polyBLEP)                             Detune  the unison spread, 0 .. 60 cents
 *  Unison   1 .. 3 oscillators, spread evenly either side of the note
 *  Sub      a sine an octave down                                Tune    +-1.5 semitones
 *  Attack, Decay, Sustain, Release   the envelope; it opens the filter by EnvMod as well as the level
 *  EnvMod   filter envelope depth, 0 .. 60 semitones            Slide   glide time, 5 ms .. 600 ms
 *  Drive    gain into the filter                                 Dist, DrvTyp   the distortion after it
 *  Ring     a ring modulator at the end: the sound times a sine that follows the note (0 = off)
 *  RingFq   the sine's frequency as a ratio of the note: 0.5x .. 8x, exponential (a whole number: harmonic; between: metallic)
 *
 * Every instance is self-contained (no mutable static state). */
#pragma once
#include <stdint.h>
#include "x0x_param.h"

#define LEAD_SR 44100.0f
#define LEAD_CTRL 8                       /* control rate: envelope, pitch and the filter coefficients */
#define LEAD_VOICES 3

enum {
    LEAD_CUTOFF, LEAD_RESO, LEAD_COLOR, LEAD_DETUNE,           /* EDIT, page 1 */
    LEAD_UNISON, LEAD_SUB, LEAD_TUNE,                          /* page 2 */
    LEAD_ATTACK, LEAD_DECAY, LEAD_SUSTAIN, LEAD_RELEASE,       /* ENV, page 1 */
    LEAD_ENVMOD, LEAD_SLIDE,                                   /* page 2 */
    LEAD_DRIVE, LEAD_DIST, LEAD_RING, LEAD_RINGFQ,             /* FX, page 1 */
    LEAD_DISTTYPE,                                             /* page 2 */
    LEAD_NPARAMS
};

typedef struct lead {
    uint8_t pot[LEAD_NPARAMS];

    /* derived from the pots */
    float cut_st, reso_k, color, detune_ct, sub, tune_st, env_st;
    int nvoices;
    float ratio[LEAD_VOICES];     /* each oscillator's frequency ratio to the note */
    float att_step;               /* attack: envelope step per sample */
    float dec_c, sustain, rel_c;  /* decay (per sample), the level it settles at, release (per sample) */
    float glide_c;                /* per control step */
    float drive_g, dist_g, dist_wet, dist_norm;
    float ring_mix, ring_ratio, ring_ph;
    int dist_type;

    /* voice */
    int gate, idle, snap;
    int stage;                    /* 0 attack, 1 decay / sustain, 2 release */
    int cc;
    float target_st, cur_st;
    float env;
    float inc0, inc1, sub_ph;
    float ph[LEAD_VOICES];
    float G, G2, G3, G4, kk, rdiv;
    float s1, s2, s3, s4;
} lead_t;

void lead_init(lead_t *b);
void lead_note_on(lead_t *b, int note, int slide);
void lead_note_off(lead_t *b);
void lead_all_off(lead_t *b);
void lead_render(lead_t *b, float *out, int n);
int lead_nparams(void);
const x0x_param_t *lead_param(int i);
void lead_set(lead_t *b, int i, int value);
int lead_get(const lead_t *b, int i);
