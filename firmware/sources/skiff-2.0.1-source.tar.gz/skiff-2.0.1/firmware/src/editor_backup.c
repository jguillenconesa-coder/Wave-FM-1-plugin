/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* Complete musical archive: no raw addresses are accepted. Small objects are staged
 * in main-loop RAM and fully validated before the existing A/B commit path writes.
 * Sample restore uses SMP_BEGIN/WRITE/END and its existing CRC/header-last commit.
 * A disconnected sample restore can lose that sample; the exported file is retained.
 * Id 8 (the FM6 patch bank of 1.0..1.0.2) is listed empty since 1.0.3; a PUT of it from an older archive moves its
 * patches into the user presets restored before it (ids 6, 7), as the first boot after the update does (up_fm6.c);
 * (2.0) only with FELUCCA_LEGACY, the converter's (web/conv): 2.0 takes it empty, and its projects SKF3 and SKF4 (the
 * editor converts the others first); a slot's whole project of before (one the converter couldn't: the archive's
 * patterns full) is kept as it is, OLD FORMAT, and backed up as flash keeps it (proj_old).
 * Id 9 is the user presets' FM6 patches (up_fm6.c), appended in 1.0.3.
 * (Skiff) Ids 16..31 are the pattern bank's 16 chunks (bank.c, each 4 patterns; 0 bytes: all empty): a restore checks
 * every pattern, then writes the chunk as a save does (its commit record last). Firmware without the bank refuses them
 * (rc 1 at begin, nothing written): the web tool skips them there.
 */
static const uint8_t ED_BK_IDS[29] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28,
                                      29, 30, 31, 32, 33, 34};
#define ED_BK_BANK(id) ((id) >= 16u && (id) < 32u)   /* (Skiff) the pattern bank's chunks */
#define ED_BK_N ((uint32_t)sizeof ED_BK_IDS)
#define ED_BK_MAX ((uint32_t)sizeof proj_wire_u.raw)
#define ED_BK_RAW (proj_wire_u.raw)  /* reuse the existing serialized main-loop scratch */
_Static_assert(sizeof proj_wire_u.raw >= sizeof(upf_t) && sizeof proj_wire_u.raw >= sizeof(fm6_bank_t), "backup staging");
static sks_t ed_bk_settings;
static uint8_t ed_bk_valid, ed_bk_put, ed_bk_id, ed_bk_gen;
static uint32_t ed_bk_len, ed_bk_crc, ed_bk_pos, ed_bk_ms, ed_bk_usb;
static void ed_bk_u32(uint32_t n) { for (uint32_t i = 0; i < 5u; i++) ed_b((n >> (i * 7u)) & 127u); }
static uint32_t ed_bk_r32(const uint8_t *p)
{
    return (uint32_t)p[0] | (uint32_t)p[1] << 7 | (uint32_t)p[2] << 14 | (uint32_t)p[3] << 21 | (uint32_t)p[4] << 28;
}
static void ed_bk_pack(const uint8_t *p, uint32_t n)
{
    while (n) {
        uint32_t k = n > 7u ? 7u : n, mask = 0;
        for (uint32_t i = 0; i < k; i++) mask |= (uint32_t)(p[i] >> 7) << i;
        ed_b(mask);
        for (uint32_t i = 0; i < k; i++) ed_b(p[i]);
        p += k; n -= k;
    }
}
static const uint8_t *ed_bk_object(uint32_t id, uint32_t *len)
{
    *len = 0;
    if (id == 0u) { *len = PROJ_SKF->size; return ED_BK_RAW; }    /* (Skiff phase 5: SKF2; phase 6: SKF3; 2.0: SKF4) */
    if (id == 1u) { *len = sizeof ed_bk_settings; return (const uint8_t *)&ed_bk_settings; }
    if (id >= 2u && id <= 5u) {                     /* ((2.0) the record's own size; one of a format of before as flash
                                                     * keeps it, for the editor's Restore to convert: proj_old) */
        const proj_fmt_t *f = proj_fmt_of(&proj_slot[id - 2u], sizeof proj_slot[0]);
#if FELUCCA_FLASH
        st_hdr_t h;
        if (proj_old(id - 2u) && st_current(OBJ_PROJECT0 + id - 2u, &h) >= 0) { *len = h.len; return st_buf; }
#endif
        if (project_used(id - 2u) && !proj_old(id - 2u)) *len = f ? f->size : sizeof proj_slot[0];   /* (the converter's
                                                                                                * SKF1: the slot) */
        return (const uint8_t *)&proj_slot[id - 2u];
    }
    if (id == 6u || id == 7u) {
        if (up_bank[id - 6u].magic == UP_BANK_MAGIC) *len = sizeof up_bank[0];
        return (const uint8_t *)&up_bank[id - 6u];
    }
    if (id == 8u)                                   /* the retired FM6 patch bank: always empty */
        return ED_BK_RAW;
    if (id == 9u) {                                 /* the user presets' FM6 patches */
        if (upf_valid(&upf)) *len = sizeof upf;
        return (const uint8_t *)&upf;
    }
    if (ED_BK_BANK(id))                             /* (Skiff) a bank chunk, read into bank.c's buffer */
        return bank_chunk(id - 16u, len);
    if (id >= 32u && id < 32u + SMP_USER_SLOTS) {
        uint32_t k = id - 32u;
        const smp_user_hdr_t *h = (const smp_user_hdr_t *)smp_user_xip(k);
        if (usr_nz[k] && h->magic == SMP_USER_MAGIC && h->data_len <= SMP_USER_SIZE - SMP_USER_DATA)
            *len = SMP_USER_DATA + h->data_len;
        return smp_user_xip(k);
    }
    return 0;
}
static uint32_t ed_bk_capture(void)
{
    if (ed_flash_stop()) return 3;
    (void)keep_all();                               /* (phase 5) the tracks' patterns written: the chunks hold them */
    project_capture(&proj_scratch);
    if (!proj_pack2((project_store_t *)ED_BK_RAW, &proj_scratch, PROJ_SKF)) return 2;
    ed_bk_gen = ++proj_wire_gen;
#if FELUCCA_FLASH
    ed_bk_settings = persist_saved;                 /* fields absent from this build survive */
#else
    memset(&ed_bk_settings, 0, sizeof ed_bk_settings);
#endif
    settings_export(&ed_bk_settings);
    ed_bk_put = 0; ed_bk_valid = 1; ed_bk_usb = usb.resets;
    return 0;
}
static int ed_bk_panel_valid(const panel_t *p)
{
    uint32_t b = 0, e = 0;
    if (p->magic != PANEL_MAGIC) return 0;
    for (uint32_t i = 0; i < NB; i++) {
        if (p->btn[i] >= PANEL_NBTN || (b & (1u << p->btn[i]))) return 0;
        b |= 1u << p->btn[i];
    }
    for (uint32_t i = 0; i < NE; i++) {
        if (p->enc[i] >= PANEL_NENC || (e & (1u << p->enc[i])) || (p->dir[i] != 1 && p->dir[i] != -1)) return 0;
        e |= 1u << p->enc[i];
    }
    return 1;
}
static int ed_bk_set_ok(uint32_t palette, uint32_t lowcut, uint32_t zoom, uint32_t bold, uint32_t filter,
                        const panel_t *panel)   /* (a settings record's fields, PER4's or SKS1's) */
{
    return palette_stored_ok(palette) && lowcut <= 2u && leds_stored_ok(zoom) && hold_stored_ok(bold) && filter <= 1u &&
           ed_bk_panel_valid(panel);
}
static uint32_t ed_bk_commit(void)
{
    uint8_t *raw = ED_BK_RAW;
    uint32_t obj, old = 0;
    if (ed_bk_pos != ed_bk_len || st_crc32(raw, ed_bk_len) != ed_bk_crc) return 2;
    if (ed_bk_id == 0u || (ed_bk_id >= 2u && ed_bk_id <= 5u)) {
        if (ed_bk_len && !proj_import(&proj_scratch, raw, (int)ed_bk_len)) {   /* ((2.0) SKF3, SKF4: the editor converts */
            if (FELUCCA_LEGACY || !ed_bk_id || !(old = proj_old_whole(raw, ed_bk_len)))   /* the others; one it couldn't, */
                return 2;                           /* whole, kept as it is: OLD FORMAT, converted another time) */
            ed_bk_len = old;
        }
        if (ed_bk_len && !old) {                    /* SKF2 .. SKF4 as they are; an older format becomes SKF1 inside its */
            const proj_fmt_t *f = proj_fmt_of(raw, (int)ed_bk_len);   /* ranges */
            proj_bound(&proj_scratch);
#if FELUCCA_LEGACY
            if (!(f ? proj_pack2((project_store_t *)raw, &proj_scratch, f)
                    : proj_pack((project_store_t *)raw, &proj_scratch)))
                return 2;
            ed_bk_len = f ? f->size : sizeof(project_store_t);
#else
            if (!proj_pack2((project_store_t *)raw, &proj_scratch, f))
                return 2;
            ed_bk_len = f->size;
#endif
        }
        if (ed_bk_id == 0u) {                       /* (the last object of a restore: fm1backup.js) */
            if (!ed_bk_len || project_restore_runtime(&proj_scratch)) return 2;
#if FELUCCA_LEGACY
            (void)proj_migrate(1);                  /* (phase 5) an older archive's projects (ids 2..5): SKF2 (SKF3) */
#endif
            return 0;
        }
        obj = OBJ_PROJECT0 + ed_bk_id - 2u;
    } else if (ed_bk_id == 1u) {                    /* ((2.0) SKS1; an archive of before's PER4 read, then written as SKS1) */
        const persist_t *p = (const persist_t *)raw;
        const sks_t *s = (const sks_t *)raw;
        if (ed_bk_len == sizeof *s ? s->magic != SKS_MAGIC ||
                                     !ed_bk_set_ok(s->palette, s->lowcut, s->zoom, s->bold, s->fav_filter, &s->panel)
                                   : ed_bk_len != sizeof *p || p->magic != PERSIST_MAGIC ||
                                     !ed_bk_set_ok(p->palette, p->lowcut, p->zoom, p->bold, p->favorites.filter, &p->panel))
            return 2;
        if (ed_bk_len != sizeof *s) {
            settings_import(raw, (int)ed_bk_len);
            memset(&ed_bk_settings, 0, sizeof ed_bk_settings);
            settings_export(&ed_bk_settings);
            memcpy(raw, &ed_bk_settings, sizeof ed_bk_settings);
            ed_bk_len = sizeof ed_bk_settings;
        }
        obj = OBJ_SETTINGS;
    } else if (ed_bk_id == 6u || ed_bk_id == 7u) {
        const up_bank_t *p = (const up_bank_t *)raw;
        if (ed_bk_len && (ed_bk_len != sizeof *p || p->magic != UP_BANK_MAGIC ||
            p->rsize != sizeof(up_rec_t) || p->nslot != UP_PER_BANK)) return 2;
        /* Unknown record versions remain inert bytes, preserving future/older bank data. */
        obj = OBJ_UPRESET0 + ed_bk_id - 6u;
    } else if (ed_bk_id == 8u) {                    /* an older archive's FM6 bank: into the restored user presets */
        if (!ed_bk_len) return 0;
#if FELUCCA_LEGACY
        if (ed_bk_len != sizeof(fm6_bank_t) || !fm6_bank_valid((const fm6_bank_t *)raw)) return 2;
        upf_migrate((const fm6_bank_t *)raw);
        sync_reload = 1; ui.force = 1;
        return upf_save() == 2 ? 4u : 0u;
#else
        return 2;                                   /* ((2.0) the converter moves them: web/conv) */
#endif
    } else if (ed_bk_id == 9u) {                    /* the user presets' FM6 patches (0: none) */
        const upf_t *u = (const upf_t *)raw;
        if (ed_bk_len && (ed_bk_len != sizeof *u || !upf_valid(u) || (u->used >> (UP_SLOTS - 1u) >> 1))) return 2;
        if (ed_bk_len) memcpy(&upf, raw, sizeof upf); else upf_empty();
        sync_reload = 1; ui.force = 1;
        return upf_save() == 2 ? 4u : 0u;           /* (a failed write keeps the restored RAM copy) */
    } else if (ED_BK_BANK(ed_bk_id)) {              /* (Skiff) a bank chunk: every pattern checked, then written */
        if (!bank_chunk_ok(raw, ed_bk_len)) return 2;
        sync_reload = 1; ui.force = 1;
        return bank_restore(ed_bk_id - 16u, raw, ed_bk_len) ? 4u : 0u;
    } else return 1;
#if FELUCCA_FLASH
    if (!flash_ok || st_save(obj, raw, ed_bk_len)) return 4;
#else
    (void)obj;
#endif
    if (ed_bk_id >= 2u && ed_bk_id <= 5u) {
        memset(&proj_slot[ed_bk_id - 2u], 0, sizeof proj_slot[0]);
        if (proj_cur == ed_bk_id - 2u)
            proj_cur = PROJ_NO_SLOT;                     /* (another project there now: the music keeps its name) */
        if (old)
            proj_slot[ed_bk_id - 2u].align = *(const uint32_t *)raw;   /* ((2.0, D3) its magic: OLD FORMAT, as proj_fetch) */
        else if (ed_bk_len)
            memcpy(&proj_slot[ed_bk_id - 2u], raw, ed_bk_len);
    } else if (ed_bk_id == 1u) {
        memcpy(&ed_bk_settings, raw, sizeof ed_bk_settings);
        settings_import(&ed_bk_settings, sizeof ed_bk_settings);
        panel_init(); settings_init();
#if FELUCCA_FLASH
        persist_saved = ed_bk_settings; persist_pending = 0;
#endif
    } else {
        uint32_t b = ed_bk_id - 6u;
        memset(&up_bank[b], 0, sizeof up_bank[b]);
        if (ed_bk_len) memcpy(&up_bank[b], raw, ed_bk_len);
        up_bank_check(b, (int)ed_bk_len); up_gen++;
    }
    sync_reload = 1; ui.force = 1;
    return 0;
}
/* a project object's length: (Skiff) SKF4 (2.0), SKF3 (phase 6), SKF2 (phase 5), SKF1 (and 1.x's slots: SKF3 in 3840),
 * FUN9, FUN8 (before the DRUM lane levels, 1.0.x), FUN7. ((2.0) the old ones are taken, then refused at the commit) */
static int proj_store_len(uint32_t len)
{
    return len == PROJ_STORE_SIZE || len == PROJ_STORE4 || len == PROJ_STORE3 || len == PROJ_STORE2 ||
           len == PROJ_STORE_V9 || len == PROJ_STORE_V8 || len == PROJ_STORE_V7;
}
static uint32_t ed_bk_write(const uint8_t *a, uint32_t n)
{
    /* the arguments first: a malformed request never stops the transport */
    if (n < 2u || a[0] > 3u || (a[1] > 9u && !ED_BK_BANK(a[1]))) return 1;
    if (a[0] == 0u) {
        if (n != 12u || a[6] > 15u || a[11] > 15u) return 1;
        uint32_t len = ed_bk_r32(a + 2);
        if (len > ED_BK_MAX || (a[1] == 0u && !proj_store_len(len)) ||
            (a[1] == 1u && len != sizeof(persist_t) && len != sizeof(sks_t)) ||
            (a[1] >= 2u && a[1] <= 5u && len && !proj_store_len(len)) ||
            ((a[1] == 6u || a[1] == 7u) && len && len != sizeof(up_bank_t)) ||
            (a[1] == 8u && len && (!FELUCCA_LEGACY || len != sizeof(fm6_bank_t))) ||   /* ((2.0) only empty: web/conv) */
            (a[1] == 9u && len && len != sizeof(upf_t)) ||
            (ED_BK_BANK(a[1]) && len && len != BK_LEN)) return 1;
        if (ed_flash_stop()) return 3;
        ed_bk_valid = 0; ed_bk_put = 1; ed_bk_id = a[1]; ed_bk_len = len; ed_bk_gen = ++proj_wire_gen;
        ed_bk_crc = ed_bk_r32(a + 7); ed_bk_pos = 0;
        ed_bk_usb = usb.resets; ed_bk_ms = fm1_ms;
        return 0;
    }
    if (!ed_bk_put || ed_bk_id != a[1] || ed_bk_usb != usb.resets || fm1_ms - ed_bk_ms > 15000u ||
        ed_bk_gen != proj_wire_gen) {                 /* (a project save / load reused the staging RAM) */
        ed_bk_put = 0; return 5;
    }
    ed_bk_ms = fm1_ms;
    if (a[0] == 3u) { ed_bk_put = 0; return n == 2u ? 0u : 1u; }
    if (a[0] == 2u) {
        if (n != 2u) return 1;
        if (ed_flash_stop()) return 3;
        uint32_t rc = ed_bk_commit(); ed_bk_put = 0; return rc;
    }
    if (n < 9u || a[6] > 15u || ed_bk_r32(a + 2) != ed_bk_pos) return 1;
    uint32_t count = ed_unpack7(a + 7, n - 7u, ed_smp_buf, 256u);
    if (!count || count > ed_bk_len - ed_bk_pos) return 1;
    if (ed_flash_stop()) return 3;
    memcpy(ED_BK_RAW + ed_bk_pos, ed_smp_buf, count); ed_bk_pos += count;
    return 0;
}
static int ed_backup_handle(uint32_t cmd, const uint8_t *a, uint32_t n)
{
    if (cmd == ED_BACKUP_LIST) {
        uint32_t rc = n ? 1u : ed_bk_capture();
        ed_b(1); ed_b(rc); ed_b(rc ? 0u : ED_BK_N);
        if (!rc) for (uint32_t i = 0; i < ED_BK_N; i++) {
            uint32_t len;
            const uint8_t *p = ed_bk_object(ED_BK_IDS[i], &len);
            ed_b(ED_BK_IDS[i]); ed_bk_u32(len); ed_bk_u32(st_crc32(p, len));
            fm1_wdt_feed();
        }
        return 1;
    }
    if (cmd == ED_BACKUP_GET) {
        uint32_t len = 0, off = n >= 6u ? ed_bk_r32(a + 1) : 0u;
        uint32_t count = n == 8u ? (uint32_t)a[6] | (uint32_t)a[7] << 7 : 0u;
        const uint8_t *p = n ? ed_bk_object(a[0], &len) : 0;
        uint32_t rc = (!ed_bk_valid || ed_bk_usb != usb.resets || (n && !a[0] && ed_bk_gen != proj_wire_gen)) ? 5u : transport_busy() ? 3u :
            n != 8u || a[5] > 15u || !p || !count || count > 256u || off > len || count > len - off ? 1u : 0u;
        ed_b(n ? a[0] : 127u); ed_b(rc); ed_bk_u32(off); ed_b(rc ? 0u : count & 127u); ed_b(rc ? 0u : count >> 7);
        if (!rc) ed_bk_pack(p + off, count);
        return 1;
    }
    if (cmd == ED_BACKUP_PUT) {
        uint32_t rc = ed_bk_write(a, n);
        ed_b(n ? a[0] : 127u); ed_b(n >= 2u ? a[1] : 127u); ed_b(rc);
        return 1;
    }
    return 0;
}
