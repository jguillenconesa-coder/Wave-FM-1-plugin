# 105 Recording a melody

Record a melody along your song, add notes to one section, and record a second melody.

Picks up where [104](104-changing-styles.md) left off, with Polly stopped and your song of three sections. Any song with two sections or more works.

[![Watch 105 Recording a melody (1 minute)](../video/105.jpg)](../video/105.mp4)

<table>
<tr><td width="38%" valign="top"><h3>1. Start recording M1</h3>Press <b>PLAY</b>, then press <b>EDIT</b> for the Sound page. Turn <b>ALGORITHM</b> past C4 to M1 for the first melody, and press <b>REC</b>. Recording starts when the Intro ends.</td><td><img src="img/105/2-arm.jpg" alt="RECORD M1 INTO THE SONG: REC M1 after the Intro" width="100%"></td></tr>
<tr><td width="38%" valign="top"><h3>2. Play a melody</h3>Play a melody across sections 1 and 2. The top line shows the whole song. Below it are the four bars around where you are. Your notes appear in both.<br><br>Press <b>REC</b> to stop recording, then <b>PLAY</b> to stop Polly.</td><td><img src="img/105/3-line.jpg" alt="Recording M1 in section 2: the notes on the song's line and in the four bars" width="100%"></td></tr>
<tr><td width="38%" valign="top"><h3>3. Add to section 2</h3>Press <b>HOME</b> for the Home page, and <b>HOME</b> again for the Song page. The cursor is on section 2, where the song stopped.<br><br>Press <b>EDIT</b>, then <b>REC</b>, then <b>PLAY</b>. Polly clicks for one bar, and then section 2 plays.<br><br>Play a few notes. They're added to the ones already there. Press <b>REC</b>, then <b>PLAY</b>, to stop.</td><td><img src="img/105/4-punch.jpg" alt="Recording M1 in section 2: Ballad's bar 2 flashes with the new notes" width="100%"></td></tr>
<tr><td width="38%" valign="top"><h3>4. Record M2</h3>Turn <b>ALGORITHM</b> to M2 for the second melody. Press <b>REC</b>, then <b>PLAY</b>, and start playing after the bar of clicks. M1's notes show pale underneath.<br><br>Press <b>REC</b>, then <b>PLAY</b>, to stop.</td><td><img src="img/105/5-m2.jpg" alt="Recording M2 on Strings 1, M1's notes pale under it" width="100%"></td></tr>
</table>

## More in the manual

For where melodies play, clearing or copying a section's melody, and a melody's sound, see
[Melodies](../../MANUAL.md#melodies). For the count-in and the grid, see [How recording works](../../MANUAL.md#how-recording-works).
See also [The Song page](../../MANUAL.md#the-song-page-home-home-again).

Next: [106 Your own grooves](106-your-own-grooves.md)
