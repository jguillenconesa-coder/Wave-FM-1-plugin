#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-only
# Build the GitHub Pages site for release VERSION (tools/make_pages.py), check its links (tools/check_pages.py), and
# push it to the gh-pages branch of origin, replacing what was there (the branch holds only the generated site).
# The docs go up as they are in the working tree.
#   tools/publish_pages.sh 0.1            (after ./build.sh --release 0.1; PYTHON: a Python with Pillow and libraqm)
#   NO_EMU=1 tools/publish_pages.sh 0.1   (without the emulator)
set -e
cd "$(dirname "$0")/.."
V="${1:?usage: tools/publish_pages.sh VERSION}"
PY="${PYTHON:-python3}"
PKG="app/build/polly-$V.fwsc"
[ -f "$PKG" ] || { echo "no $PKG: run ./build.sh --release $V first"; exit 1; }
if [ -z "${NO_EMU:-}" ]; then
    PYTHON="$PY" sh web/emu/build.sh --release "$V"
    node tests/host/emu_test.mjs app/build/emu/app.wasm
    "$PY" tools/make_pages.py "$PKG" "$V" build/pages      # (checks emu/ with web/emu/check_published.py)
else
    "$PY" tools/make_pages.py "$PKG" "$V" build/pages --no-emu
fi
"$PY" tools/check_pages.py build/pages
REMOTE="$(git remote get-url origin)"
SHA="$(git rev-parse --short HEAD)"
cd build/pages
rm -rf .git
git init -q -b gh-pages
git add -A
git commit -q -m "Site for Polly $V (from $SHA)"
git push -q -f "$REMOTE" gh-pages
rm -rf .git
# ask GitHub Pages to build it now: a push alone has left the first deploy stuck on "building"
REPO="$(printf %s "$REMOTE" | sed -E 's#(git@github.com:|https://github.com/)##; s#\.git$##')"
gh api -X POST "repos/$REPO/pages/builds" >/dev/null 2>&1 || echo "(could not ask GitHub Pages to build: check the repository's Pages settings: branch gh-pages, folder /)"
echo "pushed the site for $V to gh-pages: https://charlesvestal.github.io/fm1-polly/"
